package com.example.caregiving.repository

import com.example.caregiving.database.dao.TreeStateDao
import com.example.caregiving.database.entity.TreeState
import kotlinx.coroutines.flow.Flow

/**
 * TreeState Repository
 * - 나무 상태 관리
 */
class TreeStateRepository(
    private val treeStateDao: TreeStateDao
) {
    
    // ==================== 조회 ====================
    
    /**
     * 나무 상태 실시간 관찰
     */
    fun getTreeState(): Flow<TreeState?> {
        return treeStateDao.getTreeState()
    }
    
    /**
     * 나무 상태 단일 조회
     */
    suspend fun getTreeStateOnce(): TreeState? {
        return treeStateDao.getTreeStateOnce()
    }
    
    
    // ==================== 초기화 ====================
    
    /**
     * 나무 초기화 (최초 1회)
     */
    suspend fun initializeTree() {
        val tree = TreeState(
            id = 1,
            growthLevel = 1,
            totalIntakes = 0,
            lastWateredAt = 0,
            consecutiveDays = 0,
            missedCount = 0,
            healthPoints = 100,
            achievements = ""
        )
        
        treeStateDao.initialize(tree)
    }
    
    
    // ==================== 수정 ====================
    
    /**
     * 나무에 물 주기
     * (복용 기록 시 IntakeRecordRepository에서 자동 호출)
     */
    suspend fun waterTree() {
        treeStateDao.waterTree()
    }
    
    /**
     * 건강도 업데이트
     */
    suspend fun updateHealth(healthPoints: Int) {
        val clamped = healthPoints.coerceIn(0, 100)
        treeStateDao.updateHealthPoints(clamped)
    }
    
    /**
     * 배지/업적 추가
     */
    suspend fun addAchievement(achievement: String) {
        // 중복 체크
        val tree = treeStateDao.getTreeStateOnce()
        if (tree != null && !tree.achievements.contains(achievement)) {
            treeStateDao.addAchievement(achievement)
        }
    }
    
    /**
     * 나무 완전 리셋
     */
    suspend fun resetTree() {
        treeStateDao.resetTree()
    }
    
    
    // ==================== 통계 & 상태 ====================
    
    /**
     * 다음 레벨까지 남은 복용 횟수
     */
    suspend fun getIntakesUntilNextLevel(): Int {
        val tree = treeStateDao.getTreeStateOnce() ?: return 15
        
        if (tree.growthLevel >= 4) {
            return 0 // 이미 만렙
        }
        
        val nextLevelIntakes = tree.growthLevel * 15
        val remaining = nextLevelIntakes - tree.totalIntakes
        
        return maxOf(0, remaining)
    }
    
    /**
     * 레벨 진행률 (0.0 ~ 1.0)
     */
    suspend fun getLevelProgress(): Float {
        val tree = treeStateDao.getTreeStateOnce() ?: return 0f
        
        if (tree.growthLevel >= 4) {
            return 1.0f // 만렙
        }
        
        val currentLevelStart = (tree.growthLevel - 1) * 15
        val nextLevelStart = tree.growthLevel * 15
        val levelRange = nextLevelStart - currentLevelStart
        val progress = tree.totalIntakes - currentLevelStart
        
        return (progress.toFloat() / levelRange).coerceIn(0f, 1f)
    }
    
    /**
     * 나무 건강 상태 판단
     */
    suspend fun getHealthStatus(): HealthStatus {
        val tree = treeStateDao.getTreeStateOnce() ?: return HealthStatus.UNKNOWN
        
        return when {
            tree.healthPoints >= 80 -> HealthStatus.EXCELLENT
            tree.healthPoints >= 60 -> HealthStatus.GOOD
            tree.healthPoints >= 40 -> HealthStatus.FAIR
            tree.healthPoints >= 20 -> HealthStatus.POOR
            else -> HealthStatus.CRITICAL
        }
    }
    
    /**
     * 나무가 시들었는지 확인
     */
    suspend fun isTreeWithered(): Boolean {
        val tree = treeStateDao.getTreeStateOnce() ?: return false
        
        if (tree.lastWateredAt == 0L) {
            return false // 아직 복용 안 함
        }
        
        val hoursSinceLastWater = 
            (System.currentTimeMillis() - tree.lastWateredAt) / (1000 * 60 * 60)
        
        return hoursSinceLastWater > 48 // 48시간 이상
    }
}

/**
 * 나무 건강 상태 Enum
 */
enum class HealthStatus {
    EXCELLENT,  // 80-100
    GOOD,       // 60-79
    FAIR,       // 40-59
    POOR,       // 20-39
    CRITICAL,   // 0-19
    UNKNOWN     // 상태 알 수 없음
}
