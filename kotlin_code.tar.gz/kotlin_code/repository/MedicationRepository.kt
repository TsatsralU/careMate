package com.example.caregiving.repository

import com.example.caregiving.database.dao.MedicationDao
import com.example.caregiving.database.entity.Medication
import com.example.caregiving.database.entity.MedicationType
import kotlinx.coroutines.flow.Flow

/**
 * Medication Repository
 * - DAO와 ViewModel 사이의 중간 계층
 * - 비즈니스 로직 처리
 */
class MedicationRepository(
    private val medicationDao: MedicationDao
) {
    
    // ==================== 조회 ====================
    
    /**
     * 모든 약/영양제 조회
     */
    fun getAllMedications(): Flow<List<Medication>> {
        return medicationDao.getAllMedications()
    }
    
    /**
     * ID로 조회
     */
    suspend fun getMedicationById(id: Int): Medication? {
        return medicationDao.getMedicationById(id)
    }
    
    /**
     * 타입별 조회
     */
    fun getMedicationsByType(type: MedicationType): Flow<List<Medication>> {
        return medicationDao.getMedicationsByType(type)
    }
    
    /**
     * 의약품만
     */
    fun getMedicines(): Flow<List<Medication>> {
        return medicationDao.getMedicines()
    }
    
    /**
     * 영양제만
     */
    fun getSupplements(): Flow<List<Medication>> {
        return medicationDao.getSupplements()
    }
    
    /**
     * 비콘으로 약 찾기
     */
    suspend fun getMedicationByBeacon(beaconId: String): Medication? {
        return medicationDao.getMedicationByBeaconId(beaconId)
    }
    
    /**
     * 검색
     */
    fun searchMedications(query: String): Flow<List<Medication>> {
        return medicationDao.searchMedications(query)
    }
    
    
    // ==================== 삽입/수정 ====================
    
    /**
     * 약 등록
     * @return 생성된 ID
     */
    suspend fun insertMedication(medication: Medication): Long {
        return medicationDao.insert(medication)
    }
    
    /**
     * 여러 약 한 번에 등록
     */
    suspend fun insertMedications(medications: List<Medication>): List<Long> {
        return medicationDao.insertAll(medications)
    }
    
    /**
     * 약 정보 수정
     */
    suspend fun updateMedication(medication: Medication) {
        medicationDao.update(medication.copy(updatedAt = System.currentTimeMillis()))
    }
    
    /**
     * 비콘 연결
     */
    suspend fun linkBeacon(medicationId: Int, beaconId: String) {
        medicationDao.linkBeacon(medicationId, beaconId)
    }
    
    /**
     * 비콘 연결 해제
     */
    suspend fun unlinkBeacon(medicationId: Int) {
        medicationDao.unlinkBeacon(medicationId)
    }
    
    
    // ==================== 삭제 ====================
    
    /**
     * 약 삭제
     */
    suspend fun deleteMedication(medication: Medication) {
        medicationDao.delete(medication)
    }
    
    /**
     * ID로 삭제
     */
    suspend fun deleteMedicationById(id: Int) {
        medicationDao.deleteById(id)
    }
    
    
    // ==================== 통계 ====================
    
    /**
     * 총 약 개수
     */
    suspend fun getMedicationCount(): Int {
        return medicationDao.getMedicationCount()
    }
    
    /**
     * 타입별 개수
     */
    suspend fun getCountByType(type: MedicationType): Int {
        return medicationDao.getCountByType(type)
    }
    
    /**
     * 의약품/영양제 개수
     */
    suspend fun getMedicineAndSupplementCount(): Pair<Int, Int> {
        val medicineCount = medicationDao.getCountByType(MedicationType.MEDICINE)
        val supplementCount = medicationDao.getCountByType(MedicationType.SUPPLEMENT)
        return Pair(medicineCount, supplementCount)
    }
}
