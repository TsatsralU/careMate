package com.example.caregiving.repository

import com.example.caregiving.database.dao.IntakeRecordDao
import com.example.caregiving.database.dao.TreeStateDao
import com.example.caregiving.database.entity.IntakeRecord
import com.example.caregiving.database.entity.DetectionMethod
import kotlinx.coroutines.flow.Flow
import java.util.*

/**
 * IntakeRecord Repository
 * - 복용 기록 관리
 * - 나무 성장 자동 처리
 */
class IntakeRecordRepository(
    private val intakeRecordDao: IntakeRecordDao,
    private val treeStateDao: TreeStateDao
) {
    
    // ==================== 조회 ====================
    
    /**
     * 모든 복용 기록
     */
    fun getAllRecords(): Flow<List<IntakeRecord>> {
        return intakeRecordDao.getAllRecords()
    }
    
    /**
     * 특정 약의 복용 기록
     */
    fun getRecordsByMedication(medicationId: Int): Flow<List<IntakeRecord>> {
        return intakeRecordDao.getRecordsByMedication(medicationId)
    }
    
    /**
     * 오늘의 복용 기록
     */
    fun getTodayRecords(): Flow<List<IntakeRecord>> {
        val todayStart = getTodayStartTime()
        return intakeRecordDao.getTodayRecords(todayStart)
    }
    
    /**
     * 최근 N일 기록
     */
    fun getRecentRecords(days: Int): Flow<List<IntakeRecord>> {
        val startTime = System.currentTimeMillis() - (days * 24 * 60 * 60 * 1000L)
        return intakeRecordDao.getRecentRecords(startTime)
    }
    
    
    // ==================== 복용 기록 ====================
    
    /**
     * 복용 기록 + 나무 자동 성장
     * 
     * @param medicationId 약 ID
     * @param detectionMethod 감지 방법
     * @param note 메모
     * @return 생성된 복용 기록 ID
     */
    suspend fun recordIntake(
        medicationId: Int,
        detectionMethod: DetectionMethod,
        note: String? = null
    ): Long {
        // 1. 복용 기록 저장
        val record = IntakeRecord(
            medicationId = medicationId,
            takenAt = System.currentTimeMillis(),
            isConfirmed = true,
            detectionMethod = detectionMethod,
            note = note
        )
        
        val recordId = intakeRecordDao.insert(record)
        
        // 2. 나무에 물 주기 (자동 성장)
        treeStateDao.waterTree()
        
        // 3. 연속 복용 일수 계산 및 업데이트
        updateConsecutiveDays()
        
        return recordId
    }
    
    /**
     * 알람만 울림 (미복용)
     */
    suspend fun recordAlarmOnly(medicationId: Int): Long {
        val record = IntakeRecord(
            medicationId = medicationId,
            takenAt = System.currentTimeMillis(),
            isConfirmed = false,
            detectionMethod = DetectionMethod.ALARM,
            note = "알람만 울림 (미복용)"
        )
        
        val recordId = intakeRecordDao.insert(record)
        
        // 놓친 횟수 증가
        treeStateDao.incrementMissedCount()
        
        return recordId
    }
    
    
    // ==================== 연속 복용 일수 계산 ====================
    
    /**
     * 연속 복용 일수 업데이트
     */
    private suspend fun updateConsecutiveDays() {
        val sevenDaysAgo = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000L)
        val dates = intakeRecordDao.getRecentIntakeDates(sevenDaysAgo)
        
        if (dates.isEmpty()) {
            treeStateDao.resetConsecutiveDays()
            return
        }
        
        // 연속된 날짜 개수 계산
        var consecutiveDays = 1
        
        for (i in 0 until dates.size - 1) {
            val date1 = parseDate(dates[i])
            val date2 = parseDate(dates[i + 1])
            
            val daysDiff = getDaysDifference(date1, date2)
            
            if (daysDiff == 1) {
                consecutiveDays++
            } else {
                break
            }
        }
        
        // DB 업데이트
        val tree = treeStateDao.getTreeStateOnce()
        if (tree != null && tree.consecutiveDays != consecutiveDays) {
            if (consecutiveDays > tree.consecutiveDays) {
                treeStateDao.incrementConsecutiveDays()
            } else {
                treeStateDao.resetConsecutiveDays()
            }
        }
    }
    
    /**
     * 날짜 차이 계산 (일 단위)
     */
    private fun getDaysDifference(date1: Date, date2: Date): Int {
        val diff = date1.time - date2.time
        return (diff / (1000 * 60 * 60 * 24)).toInt()
    }
    
    /**
     * 문자열 → Date 변환
     */
    private fun parseDate(dateString: String): Date {
        val calendar = Calendar.getInstance()
        val parts = dateString.split("-")
        calendar.set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt())
        return calendar.time
    }
    
    /**
     * 오늘 시작 시간 (00:00:00)
     */
    private fun getTodayStartTime(): Long {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        return calendar.timeInMillis
    }
    
    
    // ==================== 통계 ====================
    
    /**
     * 총 복용 횟수
     */
    suspend fun getTotalIntakeCount(): Int {
        return intakeRecordDao.getTotalIntakeCount()
    }
    
    /**
     * 오늘 복용 횟수
     */
    suspend fun getTodayIntakeCount(): Int {
        val todayStart = getTodayStartTime()
        return intakeRecordDao.getTodayIntakeCount(todayStart)
    }
    
    /**
     * 특정 약의 복용 횟수
     */
    suspend fun getIntakeCountByMedication(medicationId: Int): Int {
        return intakeRecordDao.getIntakeCountByMedication(medicationId)
    }
    
    /**
     * 감지 방법별 통계
     */
    suspend fun getStatsByDetectionMethod(): Map<DetectionMethod, Int> {
        return intakeRecordDao.getStatsByDetectionMethod()
    }
}
