package com.example.caregiving.util

import android.content.Context
import com.example.caregiving.database.AppDatabase
import com.example.caregiving.database.entity.Medication
import com.example.caregiving.database.entity.MedicationType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * 초기 데이터 임포트 유틸리티
 * - CSV 파일에서 약 데이터 로드
 */
object DataImportUtil {
    
    /**
     * 초기 데이터가 필요하면 임포트
     * 
     * @param context Android Context
     * @param database AppDatabase 인스턴스
     * @return 임포트된 약 개수
     */
    suspend fun importIfNeeded(
        context: Context,
        database: AppDatabase
    ): Int = withContext(Dispatchers.IO) {
        
        // 이미 데이터가 있으면 스킵
        val existingCount = database.medicationDao().getMedicationCount()
        if (existingCount > 0) {
            return@withContext 0
        }
        
        // CSV 파일에서 데이터 로드
        val medications = loadMedicationsFromCsv(context)
        
        // DB에 삽입
        database.medicationDao().insertAll(medications)
        
        return@withContext medications.size
    }
    
    /**
     * CSV 파일 파싱
     * 
     * 파일 위치: app/src/main/assets/initial_medications.csv
     * 
     * CSV 형식:
     * name,type,dosage,description
     * 비타민C 1000mg,SUPPLEMENT,1일 1회 1정,면역력 증진
     */
    private fun loadMedicationsFromCsv(context: Context): List<Medication> {
        val medications = mutableListOf<Medication>()
        
        try {
            val inputStream = context.assets.open("initial_medications.csv")
            val reader = BufferedReader(InputStreamReader(inputStream))
            
            // 첫 줄(헤더) 스킵
            reader.readLine()
            
            // 데이터 읽기
            reader.forEachLine { line ->
                if (line.isNotBlank()) {
                    val medication = parseCsvLine(line)
                    if (medication != null) {
                        medications.add(medication)
                    }
                }
            }
            
            reader.close()
            
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        return medications
    }
    
    /**
     * CSV 한 줄 파싱
     */
    private fun parseCsvLine(line: String): Medication? {
        return try {
            val parts = line.split(",").map { it.trim() }
            
            if (parts.size < 3) {
                return null
            }
            
            val name = parts[0]
            val type = when (parts[1].uppercase()) {
                "MEDICINE" -> MedicationType.MEDICINE
                "SUPPLEMENT" -> MedicationType.SUPPLEMENT
                else -> MedicationType.SUPPLEMENT
            }
            val dosage = parts[2]
            val description = if (parts.size > 3) parts[3] else null
            
            Medication(
                name = name,
                type = type,
                dosage = dosage,
                description = description
            )
            
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
    
    /**
     * 샘플 데이터 생성 (CSV 파일 없을 때)
     */
    fun generateSampleData(): List<Medication> {
        return listOf(
            // 영양제
            Medication(
                name = "비타민C 1000mg",
                type = MedicationType.SUPPLEMENT,
                dosage = "1일 1회 1정",
                description = "면역력 증진 및 항산화"
            ),
            Medication(
                name = "비타민D 2000IU",
                type = MedicationType.SUPPLEMENT,
                dosage = "1일 1회 1캡슐",
                description = "뼈 건강 및 칼슘 흡수"
            ),
            Medication(
                name = "오메가3 1200mg",
                type = MedicationType.SUPPLEMENT,
                dosage = "1일 2회 각 1캡슐",
                description = "혈행 개선 및 눈 건강"
            ),
            Medication(
                name = "유산균 100억",
                type = MedicationType.SUPPLEMENT,
                dosage = "1일 1회 1포",
                description = "장 건강 및 배변 활동"
            ),
            Medication(
                name = "종합비타민",
                type = MedicationType.SUPPLEMENT,
                dosage = "1일 1회 1정",
                description = "전반적 영양 보충"
            ),
            
            // 의약품
            Medication(
                name = "타이레놀 500mg",
                type = MedicationType.MEDICINE,
                dosage = "증상 있을 시 1회 1~2정",
                description = "해열 및 진통"
            ),
            Medication(
                name = "아스피린 100mg",
                type = MedicationType.MEDICINE,
                dosage = "1일 1회 1정",
                description = "혈전 예방"
            ),
            Medication(
                name = "가스활명수",
                type = MedicationType.MEDICINE,
                dosage = "증상 있을 시 1회 1병",
                description = "소화불량 개선"
            ),
            Medication(
                name = "베아제",
                type = MedicationType.MEDICINE,
                dosage = "식후 1회 1~2정",
                description = "소화 효소 보충"
            ),
            Medication(
                name = "겔포스",
                type = MedicationType.MEDICINE,
                dosage = "증상 있을 시 1회 1~2정",
                description = "제산 및 위장 보호"
            )
        )
    }
}
