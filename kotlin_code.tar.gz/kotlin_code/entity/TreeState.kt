package com.example.caregiving.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 나무 상태 Entity
 * - 디지털 생명체(나무)의 성장 상태 관리
 * - 단일 레코드로 관리 (id는 항상 1)
 */
@Entity(tableName = "tree_state")
data class TreeState(
    @PrimaryKey
    val id: Int = 1,  // 항상 1로 고정 (싱글톤 레코드)
    
    /**
     * 나무 성장 단계 (1~4)
     * 1: 씨앗 🌱
     * 2: 새싹 🌿
     * 3: 화분 🪴
     * 4: 완전 성장 🌳
     */
    val growthLevel: Int = 1,
    
    /**
     * 총 복용 횟수
     * - 나무 성장의 기준 데이터
     * - 복용 1회당 경험치 증가
     */
    val totalIntakes: Int = 0,
    
    /**
     * 마지막으로 물을 준 시간 (= 약을 먹은 시간)
     * - timestamp 형식
     */
    val lastWateredAt: Long = 0,
    
    /**
     * 연속 복용 일수
     * - 하루라도 건너뛰면 0으로 리셋
     * - 연속 복용 보너스 계산에 활용
     */
    val consecutiveDays: Int = 0,
    
    /**
     * 총 건너뛴 횟수
     * - 알람이 울렸지만 복용하지 않은 횟수
     * - 나무가 시들 때 참고
     */
    val missedCount: Int = 0,
    
    /**
     * 현재 나무의 건강 상태 (0~100)
     * 100: 매우 건강 (잎이 풍성)
     * 50-99: 보통
     * 0-49: 약함 (잎이 시듦)
     */
    val healthPoints: Int = 100,
    
    /**
     * 나무가 획득한 배지/업적
     * 콤마로 구분된 문자열
     * 예: "FIRST_WEEK,PERFECT_MONTH,LEVEL_4"
     */
    val achievements: String = ""
)

/**
 * 나무 성장 계산 로직
 */
object TreeGrowthCalculator {
    /**
     * 복용 횟수 → 성장 레벨 변환
     * 15회마다 레벨업
     */
    fun calculateGrowthLevel(totalIntakes: Int): Int {
        return minOf(4, (totalIntakes / 15) + 1)
    }
    
    /**
     * 건강도 계산
     * - 연속 복용 시 건강도 상승
     * - 건너뛰면 건강도 하락
     */
    fun calculateHealth(
        consecutiveDays: Int, 
        missedCount: Int
    ): Int {
        val base = 100
        val bonus = minOf(consecutiveDays * 2, 20) // 최대 +20
        val penalty = minOf(missedCount * 5, 50)    // 최대 -50
        return (base + bonus - penalty).coerceIn(0, 100)
    }
    
    /**
     * 나무가 시들었는지 확인
     * - 마지막 물주기가 48시간 이상 지났는지
     */
    fun isWithered(lastWateredAt: Long): Boolean {
        val hoursSinceLastWater = 
            (System.currentTimeMillis() - lastWateredAt) / (1000 * 60 * 60)
        return hoursSinceLastWater > 48
    }
}
