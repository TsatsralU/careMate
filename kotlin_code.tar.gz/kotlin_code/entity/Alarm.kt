package com.example.caregiving.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

/**
 * 알람 설정 Entity
 * - 약/영양제별 복용 알람 관리
 * - 요일별, 시간별 설정 가능
 */
@Entity(
    tableName = "alarms",
    foreignKeys = [
        ForeignKey(
            entity = Medication::class,
            parentColumns = ["id"],
            childColumns = ["medicationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["medicationId"])
    ]
)
data class Alarm(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    
    /**
     * 알람이 설정된 약/영양제 ID
     */
    val medicationId: Int,
    
    /**
     * 알람 시간 (하루 중 분 단위)
     * 예: 
     * - 540 = 오전 9시 (9 * 60)
     * - 780 = 오후 1시 (13 * 60)
     * - 1200 = 오후 8시 (20 * 60)
     */
    val timeInMinutes: Int,
    
    /**
     * 반복 요일 설정 (콤마 구분)
     * 1=월, 2=화, 3=수, 4=목, 5=금, 6=토, 7=일
     * 예:
     * - "1,2,3,4,5" = 평일만
     * - "1,2,3,4,5,6,7" = 매일
     * - "2,4,6" = 화,목,토
     */
    val daysOfWeek: String,
    
    /**
     * 알람 활성화 여부
     */
    val isEnabled: Boolean = true,
    
    /**
     * 진동 사용 여부
     */
    val vibrate: Boolean = true,
    
    /**
     * 알람 소리 URI
     * null이면 기본 알람음 사용
     */
    val soundUri: String? = null,
    
    /**
     * 알람 레이블
     * 예: "아침 약", "점심 영양제"
     */
    val label: String? = null
)

/**
 * Helper function: 시간을 분 단위로 변환
 * 예: getTimeInMinutes(9, 30) = 570 (9시 30분)
 */
fun getTimeInMinutes(hour: Int, minute: Int): Int {
    return hour * 60 + minute
}

/**
 * Helper function: 분 단위를 시:분으로 변환
 * 예: 570.toTimeString() = "09:30"
 */
fun Int.toTimeString(): String {
    val hour = this / 60
    val minute = this % 60
    return String.format("%02d:%02d", hour, minute)
}
