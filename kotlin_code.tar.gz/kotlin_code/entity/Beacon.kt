package com.example.caregiving.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

/**
 * BLE 비콘 정보 Entity
 * - 약 통/봉투에 부착된 비콘 관리
 * - 근접 감지로 자동 복용 기록
 */
@Entity(
    tableName = "beacons",
    foreignKeys = [
        ForeignKey(
            entity = Medication::class,
            parentColumns = ["id"],
            childColumns = ["medicationId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["medicationId"])
    ]
)
data class Beacon(
    /**
     * 비콘 UUID (Primary Key)
     * BLE 비콘의 고유 식별자
     * 예: "FDA50693-A4E2-4FB1-AFCF-C6EB07647825"
     */
    @PrimaryKey
    val beaconId: String,
    
    /**
     * 연결된 약/영양제 ID
     * null이면 비콘만 등록되고 약은 미연결 상태
     */
    val medicationId: Int? = null,
    
    /**
     * RSSI 임계값 (신호 강도)
     * - RSSI가 이 값보다 높으면 "근접"으로 판단
     * - 일반적으로 -70 ~ -50 사이 값
     * 예:
     * - -50: 매우 가까움 (10cm 이내)
     * - -70: 가까움 (50cm 이내)
     * - -90: 보통 (1m 이내)
     */
    val rssiThreshold: Int = -70,
    
    /**
     * 비콘이 위치한 장소
     * 예: "거실 테이블", "침실 서랍", "냉장고"
     */
    val location: String? = null,
    
    /**
     * 비콘 활성화 여부
     * - false면 감지해도 무시
     */
    val isActive: Boolean = true,
    
    /**
     * 마지막으로 감지된 시간
     * - 비콘 배터리 상태 확인용
     */
    val lastDetectedAt: Long = 0,
    
    /**
     * 비콘 배터리 레벨 (0~100)
     * - 일부 BLE 비콘만 지원
     */
    val batteryLevel: Int? = null,
    
    /**
     * 비콘 등록 시간
     */
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * RSSI 강도별 거리 추정
 */
object BeaconDistanceCalculator {
    /**
     * RSSI 값으로 대략적인 거리 추정
     * 
     * @param rssi 신호 강도
     * @param txPower 1m 거리에서의 RSSI 값 (보통 -59)
     * @return 추정 거리 (미터)
     */
    fun estimateDistance(rssi: Int, txPower: Int = -59): Double {
        if (rssi == 0) return -1.0
        
        val ratio = rssi * 1.0 / txPower
        return if (ratio < 1.0) {
            Math.pow(ratio, 10.0)
        } else {
            0.89976 * Math.pow(ratio, 7.7095) + 0.111
        }
    }
    
    /**
     * 거리 범주 판단
     */
    enum class Proximity {
        IMMEDIATE,  // 즉시 (10cm 이내)
        NEAR,       // 가까움 (50cm 이내)
        FAR,        // 멀리 (1m 이상)
        UNKNOWN     // 알 수 없음
    }
    
    fun getProximity(rssi: Int): Proximity {
        return when {
            rssi >= -50 -> Proximity.IMMEDIATE
            rssi >= -70 -> Proximity.NEAR
            rssi >= -90 -> Proximity.FAR
            else -> Proximity.UNKNOWN
        }
    }
}
