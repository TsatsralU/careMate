package com.example.caregiving.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

/**
 * 약/영양제 정보 Entity
 * - 의약품과 건강기능식품(영양제)를 모두 관리
 * - BLE 비콘과 1:1 매핑 가능
 */
@Entity(
    tableName = "medications",
    indices = [
        Index(value = ["beaconId"]),
        Index(value = ["type"])
    ]
)
data class Medication(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    
    /**
     * 약/영양제 이름
     * 예: "타이레놀", "비타민C 1000mg"
     */
    val name: String,
    
    /**
     * 종류 구분
     * MEDICINE: 의약품
     * SUPPLEMENT: 건강기능식품(영양제)
     */
    val type: MedicationType,
    
    /**
     * 용량/용법
     * 예: "1정", "500mg", "1회 2캡슐"
     */
    val dosage: String,
    
    /**
     * 상세 설명
     * 예: "해열진통제", "비타민C 면역력 강화"
     */
    val description: String? = null,
    
    /**
     * 약 이미지 URL 또는 로컬 경로
     */
    val imageUrl: String? = null,
    
    /**
     * 연결된 BLE 비콘 ID (UUID)
     * null이면 비콘 미연결 상태
     */
    val beaconId: String? = null,
    
    /**
     * 등록 시간
     */
    val createdAt: Long = System.currentTimeMillis(),
    
    /**
     * 최종 수정 시간
     */
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * 약 종류 Enum
 */
enum class MedicationType {
    MEDICINE,      // 의약품
    SUPPLEMENT     // 건강기능식품(영양제)
}
