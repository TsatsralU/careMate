package com.example.caregiving.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

/**
 * 복용 기록 Entity
 * - 실제 약/영양제 복용 이력 저장
 * - 나무 성장 계산의 기준 데이터
 */
@Entity(
    tableName = "intake_records",
    foreignKeys = [
        ForeignKey(
            entity = Medication::class,
            parentColumns = ["id"],
            childColumns = ["medicationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["medicationId"]),
        Index(value = ["takenAt"])
    ]
)
data class IntakeRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    
    /**
     * 복용한 약/영양제 ID
     */
    val medicationId: Int,
    
    /**
     * 복용 시간 (timestamp)
     * System.currentTimeMillis()
     */
    val takenAt: Long = System.currentTimeMillis(),
    
    /**
     * 실제 복용 확인 여부
     * - true: 비콘 감지 또는 사용자 확인
     * - false: 알람만 울림 (미확인)
     */
    val isConfirmed: Boolean = false,
    
    /**
     * 감지 방법
     * BEACON: BLE 비콘으로 자동 감지
     * MANUAL: 사용자가 수동으로 체크
     * VOICE: 음성 명령으로 기록
     * ALARM: 알람만 울림 (미복용)
     */
    val detectionMethod: DetectionMethod,
    
    /**
     * 메모
     * 예: "식후 복용", "물과 함께"
     */
    val note: String? = null
)

/**
 * 복용 감지 방법 Enum
 */
enum class DetectionMethod {
    BEACON,   // BLE 비콘 자동 감지
    MANUAL,   // 수동 체크
    VOICE,    // 음성 입력
    ALARM     // 알람만 (미복용)
}
