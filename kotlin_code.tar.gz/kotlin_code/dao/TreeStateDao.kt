package com.example.caregiving.database.dao

import androidx.room.*
import com.example.caregiving.database.entity.TreeState
import kotlinx.coroutines.flow.Flow

/**
 * TreeState DAO
 * - 나무 상태 관리
 * - 단일 레코드 (id = 1)
 */
@Dao
interface TreeStateDao {
    
    // ==================== 조회 ====================
    
    /**
     * 나무 상태 조회 (실시간 관찰)
     */
    @Query("SELECT * FROM tree_state WHERE id = 1")
    fun getTreeState(): Flow<TreeState?>
    
    /**
     * 나무 상태 조회 (단일 값)
     */
    @Query("SELECT * FROM tree_state WHERE id = 1")
    suspend fun getTreeStateOnce(): TreeState?
    
    
    // ==================== 수정 ====================
    
    /**
     * 나무 상태 업데이트
     */
    @Update
    suspend fun update(treeState: TreeState)
    
    /**
     * 나무에 물 주기 (복용 기록 시 호출)
     * - 총 복용 횟수 +1
     * - 성장 레벨 자동 계산
     * - 마지막 물주기 시간 업데이트
     */
    @Query("""
        UPDATE tree_state 
        SET 
            totalIntakes = totalIntakes + 1,
            growthLevel = MIN(4, (totalIntakes + 1) / 15 + 1),
            lastWateredAt = :timestamp,
            healthPoints = MIN(100, healthPoints + 1)
        WHERE id = 1
    """)
    suspend fun waterTree(timestamp: Long = System.currentTimeMillis())
    
    /**
     * 연속 복용 일수 증가
     */
    @Query("""
        UPDATE tree_state 
        SET consecutiveDays = consecutiveDays + 1
        WHERE id = 1
    """)
    suspend fun incrementConsecutiveDays()
    
    /**
     * 연속 복용 일수 리셋
     */
    @Query("UPDATE tree_state SET consecutiveDays = 0 WHERE id = 1")
    suspend fun resetConsecutiveDays()
    
    /**
     * 놓친 횟수 증가
     */
    @Query("""
        UPDATE tree_state 
        SET 
            missedCount = missedCount + 1,
            healthPoints = MAX(0, healthPoints - 5)
        WHERE id = 1
    """)
    suspend fun incrementMissedCount()
    
    /**
     * 건강도 업데이트
     */
    @Query("UPDATE tree_state SET healthPoints = :healthPoints WHERE id = 1")
    suspend fun updateHealthPoints(healthPoints: Int)
    
    /**
     * 배지/업적 추가
     */
    @Query("""
        UPDATE tree_state 
        SET achievements = achievements || ',' || :achievement
        WHERE id = 1
    """)
    suspend fun addAchievement(achievement: String)
    
    
    // ==================== 초기화 ====================
    
    /**
     * 나무 초기화 (최초 1회만)
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun initialize(treeState: TreeState)
    
    /**
     * 나무 완전 리셋 (테스트용)
     */
    @Query("""
        UPDATE tree_state 
        SET 
            growthLevel = 1,
            totalIntakes = 0,
            lastWateredAt = 0,
            consecutiveDays = 0,
            missedCount = 0,
            healthPoints = 100,
            achievements = ''
        WHERE id = 1
    """)
    suspend fun resetTree()
}
