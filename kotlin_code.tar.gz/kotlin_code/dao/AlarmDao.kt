package com.example.caregiving.database.dao

import androidx.room.*
import com.example.caregiving.database.entity.Alarm
import kotlinx.coroutines.flow.Flow

/**
 * Alarm DAO
 * - 알람 설정 CRUD 작업
 */
@Dao
interface AlarmDao {
    
    // ==================== 삽입 ====================
    
    /**
     * 알람 추가
     * @return 생성된 ID
     */
    @Insert
    suspend fun insert(alarm: Alarm): Long
    
    /**
     * 여러 알람 한 번에 추가
     */
    @Insert
    suspend fun insertAll(alarms: List<Alarm>): List<Long>
    
    
    // ==================== 조회 ====================
    
    /**
     * 모든 알람 조회
     */
    @Query("SELECT * FROM alarms ORDER BY timeInMinutes ASC")
    fun getAllAlarms(): Flow<List<Alarm>>
    
    /**
     * 특정 약의 알람 조회
     */
    @Query("SELECT * FROM alarms WHERE medicationId = :medicationId ORDER BY timeInMinutes ASC")
    fun getAlarmsByMedication(medicationId: Int): Flow<List<Alarm>>
    
    /**
     * 활성화된 알람만 조회
     */
    @Query("SELECT * FROM alarms WHERE isEnabled = 1 ORDER BY timeInMinutes ASC")
    fun getEnabledAlarms(): Flow<List<Alarm>>
    
    /**
     * 오늘 울릴 알람 (특정 요일)
     * @param dayOfWeek 1=월, 2=화, ..., 7=일
     */
    @Query("""
        SELECT * FROM alarms 
        WHERE isEnabled = 1 
        AND daysOfWeek LIKE '%' || :dayOfWeek || '%'
        ORDER BY timeInMinutes ASC
    """)
    fun getTodayAlarms(dayOfWeek: String): Flow<List<Alarm>>
    
    /**
     * 특정 시간대의 알람 (현재 시간 기준)
     */
    @Query("""
        SELECT * FROM alarms 
        WHERE isEnabled = 1 
        AND timeInMinutes >= :startMinutes 
        AND timeInMinutes <= :endMinutes
        ORDER BY timeInMinutes ASC
    """)
    suspend fun getAlarmsInTimeRange(startMinutes: Int, endMinutes: Int): List<Alarm>
    
    /**
     * 다음 알람 가져오기 (현재 시간 이후)
     */
    @Query("""
        SELECT * FROM alarms 
        WHERE isEnabled = 1 
        AND timeInMinutes > :currentMinutes
        ORDER BY timeInMinutes ASC
        LIMIT 1
    """)
    suspend fun getNextAlarm(currentMinutes: Int): Alarm?
    
    
    // ==================== 수정 ====================
    
    /**
     * 알람 수정
     */
    @Update
    suspend fun update(alarm: Alarm)
    
    /**
     * 알람 활성화/비활성화
     */
    @Query("UPDATE alarms SET isEnabled = :isEnabled WHERE id = :alarmId")
    suspend fun setAlarmEnabled(alarmId: Int, isEnabled: Boolean)
    
    /**
     * 알람 시간 변경
     */
    @Query("UPDATE alarms SET timeInMinutes = :timeInMinutes WHERE id = :alarmId")
    suspend fun updateAlarmTime(alarmId: Int, timeInMinutes: Int)
    
    /**
     * 알람 요일 변경
     */
    @Query("UPDATE alarms SET daysOfWeek = :daysOfWeek WHERE id = :alarmId")
    suspend fun updateDaysOfWeek(alarmId: Int, daysOfWeek: String)
    
    
    // ==================== 삭제 ====================
    
    /**
     * 알람 삭제
     */
    @Delete
    suspend fun delete(alarm: Alarm)
    
    /**
     * ID로 삭제
     */
    @Query("DELETE FROM alarms WHERE id = :alarmId")
    suspend fun deleteById(alarmId: Int)
    
    /**
     * 특정 약의 모든 알람 삭제
     */
    @Query("DELETE FROM alarms WHERE medicationId = :medicationId")
    suspend fun deleteByMedication(medicationId: Int)
    
    /**
     * 모두 삭제
     */
    @Query("DELETE FROM alarms")
    suspend fun deleteAll()
}
