package com.example.caregiving.database.dao

import androidx.room.*
import com.example.caregiving.database.entity.Medication
import com.example.caregiving.database.entity.MedicationType
import kotlinx.coroutines.flow.Flow

/**
 * Medication DAO
 * - 약/영양제 CRUD 작업
 */
@Dao
interface MedicationDao {
    
    // ==================== 삽입 ====================
    
    /**
     * 약/영양제 등록
     * @return 생성된 ID
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(medication: Medication): Long
    
    /**
     * 여러 약/영양제 한 번에 등록
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(medications: List<Medication>): List<Long>
    
    
    // ==================== 조회 ====================
    
    /**
     * 모든 약/영양제 조회 (Flow로 실시간 관찰)
     */
    @Query("SELECT * FROM medications ORDER BY createdAt DESC")
    fun getAllMedications(): Flow<List<Medication>>
    
    /**
     * ID로 단일 약 조회
     */
    @Query("SELECT * FROM medications WHERE id = :medicationId")
    suspend fun getMedicationById(medicationId: Int): Medication?
    
    /**
     * 타입별 조회 (의약품/영양제)
     */
    @Query("SELECT * FROM medications WHERE type = :type ORDER BY name ASC")
    fun getMedicationsByType(type: MedicationType): Flow<List<Medication>>
    
    /**
     * 의약품만 조회
     */
    @Query("SELECT * FROM medications WHERE type = 'MEDICINE' ORDER BY name ASC")
    fun getMedicines(): Flow<List<Medication>>
    
    /**
     * 영양제만 조회
     */
    @Query("SELECT * FROM medications WHERE type = 'SUPPLEMENT' ORDER BY name ASC")
    fun getSupplements(): Flow<List<Medication>>
    
    /**
     * 비콘이 연결된 약 조회
     */
    @Query("SELECT * FROM medications WHERE beaconId = :beaconId LIMIT 1")
    suspend fun getMedicationByBeaconId(beaconId: String): Medication?
    
    /**
     * 이름으로 검색 (부분 일치)
     */
    @Query("SELECT * FROM medications WHERE name LIKE '%' || :searchQuery || '%' ORDER BY name ASC")
    fun searchMedications(searchQuery: String): Flow<List<Medication>>
    
    /**
     * 등록된 약 개수
     */
    @Query("SELECT COUNT(*) FROM medications")
    suspend fun getMedicationCount(): Int
    
    /**
     * 타입별 개수
     */
    @Query("SELECT COUNT(*) FROM medications WHERE type = :type")
    suspend fun getCountByType(type: MedicationType): Int
    
    
    // ==================== 수정 ====================
    
    /**
     * 약/영양제 정보 수정
     */
    @Update
    suspend fun update(medication: Medication)
    
    /**
     * 비콘 연결
     */
    @Query("UPDATE medications SET beaconId = :beaconId, updatedAt = :timestamp WHERE id = :medicationId")
    suspend fun linkBeacon(
        medicationId: Int, 
        beaconId: String, 
        timestamp: Long = System.currentTimeMillis()
    )
    
    /**
     * 비콘 연결 해제
     */
    @Query("UPDATE medications SET beaconId = NULL, updatedAt = :timestamp WHERE id = :medicationId")
    suspend fun unlinkBeacon(
        medicationId: Int, 
        timestamp: Long = System.currentTimeMillis()
    )
    
    
    // ==================== 삭제 ====================
    
    /**
     * 약/영양제 삭제
     */
    @Delete
    suspend fun delete(medication: Medication)
    
    /**
     * ID로 삭제
     */
    @Query("DELETE FROM medications WHERE id = :medicationId")
    suspend fun deleteById(medicationId: Int)
    
    /**
     * 모두 삭제
     */
    @Query("DELETE FROM medications")
    suspend fun deleteAll()
}
