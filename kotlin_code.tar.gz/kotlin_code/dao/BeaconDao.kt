package com.example.caregiving.database.dao

import androidx.room.*
import com.example.caregiving.database.entity.Beacon
import kotlinx.coroutines.flow.Flow

/**
 * Beacon DAO
 * - BLE 비콘 정보 CRUD 작업
 */
@Dao
interface BeaconDao {
    
    // ==================== 삽입 ====================
    
    /**
     * 비콘 등록
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(beacon: Beacon)
    
    /**
     * 여러 비콘 한 번에 등록
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(beacons: List<Beacon>)
    
    
    // ==================== 조회 ====================
    
    /**
     * 모든 비콘 조회
     */
    @Query("SELECT * FROM beacons ORDER BY createdAt DESC")
    fun getAllBeacons(): Flow<List<Beacon>>
    
    /**
     * UUID로 비콘 조회
     */
    @Query("SELECT * FROM beacons WHERE beaconId = :beaconId")
    suspend fun getBeaconById(beaconId: String): Beacon?
    
    /**
     * 활성화된 비콘만 조회
     */
    @Query("SELECT * FROM beacons WHERE isActive = 1")
    fun getActiveBeacons(): Flow<List<Beacon>>
    
    /**
     * 약에 연결된 비콘 조회
     */
    @Query("SELECT * FROM beacons WHERE medicationId = :medicationId")
    suspend fun getBeaconByMedication(medicationId: Int): Beacon?
    
    /**
     * 연결되지 않은 비콘 조회
     */
    @Query("SELECT * FROM beacons WHERE medicationId IS NULL")
    fun getUnlinkedBeacons(): Flow<List<Beacon>>
    
    /**
     * 위치별 비콘 조회
     */
    @Query("SELECT * FROM beacons WHERE location LIKE '%' || :location || '%'")
    fun getBeaconsByLocation(location: String): Flow<List<Beacon>>
    
    
    // ==================== 수정 ====================
    
    /**
     * 비콘 정보 수정
     */
    @Update
    suspend fun update(beacon: Beacon)
    
    /**
     * 비콘 활성화/비활성화
     */
    @Query("UPDATE beacons SET isActive = :isActive WHERE beaconId = :beaconId")
    suspend fun setBeaconActive(beaconId: String, isActive: Boolean)
    
    /**
     * 약 연결
     */
    @Query("UPDATE beacons SET medicationId = :medicationId WHERE beaconId = :beaconId")
    suspend fun linkToMedication(beaconId: String, medicationId: Int)
    
    /**
     * 약 연결 해제
     */
    @Query("UPDATE beacons SET medicationId = NULL WHERE beaconId = :beaconId")
    suspend fun unlinkFromMedication(beaconId: String)
    
    /**
     * 마지막 감지 시간 업데이트
     */
    @Query("UPDATE beacons SET lastDetectedAt = :timestamp WHERE beaconId = :beaconId")
    suspend fun updateLastDetected(beaconId: String, timestamp: Long = System.currentTimeMillis())
    
    /**
     * 배터리 레벨 업데이트
     */
    @Query("UPDATE beacons SET batteryLevel = :batteryLevel WHERE beaconId = :beaconId")
    suspend fun updateBatteryLevel(beaconId: String, batteryLevel: Int)
    
    /**
     * RSSI 임계값 변경
     */
    @Query("UPDATE beacons SET rssiThreshold = :threshold WHERE beaconId = :beaconId")
    suspend fun updateRssiThreshold(beaconId: String, threshold: Int)
    
    
    // ==================== 삭제 ====================
    
    /**
     * 비콘 삭제
     */
    @Delete
    suspend fun delete(beacon: Beacon)
    
    /**
     * UUID로 삭제
     */
    @Query("DELETE FROM beacons WHERE beaconId = :beaconId")
    suspend fun deleteById(beaconId: String)
    
    /**
     * 모두 삭제
     */
    @Query("DELETE FROM beacons")
    suspend fun deleteAll()
    
    
    // ==================== 통계 ====================
    
    /**
     * 등록된 비콘 개수
     */
    @Query("SELECT COUNT(*) FROM beacons")
    suspend fun getBeaconCount(): Int
    
    /**
     * 활성화된 비콘 개수
     */
    @Query("SELECT COUNT(*) FROM beacons WHERE isActive = 1")
    suspend fun getActiveBeaconCount(): Int
    
    /**
     * 약에 연결된 비콘 개수
     */
    @Query("SELECT COUNT(*) FROM beacons WHERE medicationId IS NOT NULL")
    suspend fun getLinkedBeaconCount(): Int
}
