package com.example.caregiving.database.dao

import androidx.room.*
import com.example.caregiving.database.entity.IntakeRecord
import com.example.caregiving.database.entity.DetectionMethod
import kotlinx.coroutines.flow.Flow

/**
 * IntakeRecord DAO
 * - 복용 기록 CRUD 작업
 */
@Dao
interface IntakeRecordDao {
    
    // ==================== 삽입 ====================
    
    /**
     * 복용 기록 추가
     * @return 생성된 ID
     */
    @Insert
    suspend fun insert(record: IntakeRecord): Long
    
    /**
     * 여러 복용 기록 한 번에 추가
     */
    @Insert
    suspend fun insertAll(records: List<IntakeRecord>): List<Long>
    
    
    // ==================== 조회 ====================
    
    /**
     * 모든 복용 기록 조회 (최근순)
     */
    @Query("SELECT * FROM intake_records ORDER BY takenAt DESC")
    fun getAllRecords(): Flow<List<IntakeRecord>>
    
    /**
     * 특정 약의 복용 기록
     */
    @Query("SELECT * FROM intake_records WHERE medicationId = :medicationId ORDER BY takenAt DESC")
    fun getRecordsByMedication(medicationId: Int): Flow<List<IntakeRecord>>
    
    /**
     * 오늘의 복용 기록
     */
    @Query("""
        SELECT * FROM intake_records 
        WHERE takenAt >= :todayStart 
        ORDER BY takenAt DESC
    """)
    fun getTodayRecords(todayStart: Long): Flow<List<IntakeRecord>>
    
    /**
     * 최근 N일간의 복용 기록
     */
    @Query("""
        SELECT * FROM intake_records 
        WHERE takenAt >= :startTime 
        ORDER BY takenAt DESC
    """)
    fun getRecentRecords(startTime: Long): Flow<List<IntakeRecord>>
    
    /**
     * 확인된 복용 기록만
     */
    @Query("SELECT * FROM intake_records WHERE isConfirmed = 1 ORDER BY takenAt DESC")
    fun getConfirmedRecords(): Flow<List<IntakeRecord>>
    
    
    // ==================== 통계 ====================
    
    /**
     * 총 복용 횟수
     */
    @Query("SELECT COUNT(*) FROM intake_records WHERE isConfirmed = 1")
    suspend fun getTotalIntakeCount(): Int
    
    /**
     * 오늘 복용 횟수
     */
    @Query("""
        SELECT COUNT(*) FROM intake_records 
        WHERE isConfirmed = 1 AND takenAt >= :todayStart
    """)
    suspend fun getTodayIntakeCount(todayStart: Long): Int
    
    /**
     * 특정 약의 총 복용 횟수
     */
    @Query("""
        SELECT COUNT(*) FROM intake_records 
        WHERE medicationId = :medicationId AND isConfirmed = 1
    """)
    suspend fun getIntakeCountByMedication(medicationId: Int): Int
    
    /**
     * 감지 방법별 통계
     */
    @Query("""
        SELECT detectionMethod, COUNT(*) as count
        FROM intake_records
        WHERE isConfirmed = 1
        GROUP BY detectionMethod
    """)
    suspend fun getStatsByDetectionMethod(): Map<DetectionMethod, Int>
    
    /**
     * 최근 N일간 날짜별 복용 여부
     * - 연속 복용 일수 계산에 사용
     */
    @Query("""
        SELECT DISTINCT DATE(takenAt / 1000, 'unixepoch') as date
        FROM intake_records
        WHERE isConfirmed = 1 AND takenAt >= :startTime
        ORDER BY date DESC
    """)
    suspend fun getRecentIntakeDates(startTime: Long): List<String>
    
    /**
     * 마지막 복용 시간
     */
    @Query("SELECT MAX(takenAt) FROM intake_records WHERE isConfirmed = 1")
    suspend fun getLastIntakeTime(): Long?
    
    
    // ==================== 수정 ====================
    
    /**
     * 복용 기록 수정
     */
    @Update
    suspend fun update(record: IntakeRecord)
    
    /**
     * 복용 확인 상태 변경
     */
    @Query("UPDATE intake_records SET isConfirmed = :isConfirmed WHERE id = :recordId")
    suspend fun updateConfirmStatus(recordId: Int, isConfirmed: Boolean)
    
    
    // ==================== 삭제 ====================
    
    /**
     * 복용 기록 삭제
     */
    @Delete
    suspend fun delete(record: IntakeRecord)
    
    /**
     * ID로 삭제
     */
    @Query("DELETE FROM intake_records WHERE id = :recordId")
    suspend fun deleteById(recordId: Int)
    
    /**
     * 특정 약의 모든 기록 삭제
     */
    @Query("DELETE FROM intake_records WHERE medicationId = :medicationId")
    suspend fun deleteByMedication(medicationId: Int)
    
    /**
     * 오래된 기록 삭제 (N일 이전)
     */
    @Query("DELETE FROM intake_records WHERE takenAt < :cutoffTime")
    suspend fun deleteOldRecords(cutoffTime: Long)
    
    /**
     * 모두 삭제
     */
    @Query("DELETE FROM intake_records")
    suspend fun deleteAll()
}
