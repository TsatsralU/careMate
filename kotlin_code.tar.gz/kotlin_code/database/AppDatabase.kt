package com.example.caregiving.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.caregiving.database.dao.*
import com.example.caregiving.database.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Room Database 메인 클래스
 * - Singleton 패턴
 * - 5개 Entity 관리
 */
@Database(
    entities = [
        Medication::class,
        IntakeRecord::class,
        TreeState::class,
        Alarm::class,
        Beacon::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    
    // DAO 추상 메서드
    abstract fun medicationDao(): MedicationDao
    abstract fun intakeRecordDao(): IntakeRecordDao
    abstract fun treeStateDao(): TreeStateDao
    abstract fun alarmDao(): AlarmDao
    abstract fun beaconDao(): BeaconDao
    
    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        
        private const val DATABASE_NAME = "caregiving_database"
        
        /**
         * Database 인스턴스 가져오기 (Singleton)
         */
        fun getDatabase(
            context: Context,
            scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
        ): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                )
                    .addCallback(DatabaseCallback(scope))
                    .fallbackToDestructiveMigration() // 개발 중에만 사용
                    .build()
                
                INSTANCE = instance
                instance
            }
        }
        
        /**
         * 테스트용 인메모리 DB
         */
        fun createInMemoryDatabase(context: Context): AppDatabase {
            return Room.inMemoryDatabaseBuilder(
                context.applicationContext,
                AppDatabase::class.java
            )
                .allowMainThreadQueries() // 테스트 전용
                .build()
        }
    }
    
    /**
     * Database Callback
     * - DB 생성 시 초기 데이터 설정
     */
    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            
            // DB 생성 시 초기화 작업
            INSTANCE?.let { database ->
                scope.launch {
                    populateDatabase(database)
                }
            }
        }
        
        /**
         * 초기 데이터 삽입
         */
        suspend fun populateDatabase(database: AppDatabase) {
            val treeDao = database.treeStateDao()
            
            // 나무 초기화 (단 1번만)
            treeDao.initialize(
                TreeState(
                    id = 1,
                    growthLevel = 1,
                    totalIntakes = 0,
                    healthPoints = 100,
                    consecutiveDays = 0
                )
            )
            
            // 필요시 초기 약 데이터 삽입
            // DataImportUtil.importIfNeeded(context, database)
        }
    }
}

/**
 * Type Converters
 * - Enum 타입을 String으로 변환
 */
class Converters {
    
    @androidx.room.TypeConverter
    fun fromMedicationType(value: MedicationType): String {
        return value.name
    }
    
    @androidx.room.TypeConverter
    fun toMedicationType(value: String): MedicationType {
        return MedicationType.valueOf(value)
    }
    
    @androidx.room.TypeConverter
    fun fromDetectionMethod(value: DetectionMethod): String {
        return value.name
    }
    
    @androidx.room.TypeConverter
    fun toDetectionMethod(value: String): DetectionMethod {
        return DetectionMethod.valueOf(value)
    }
}
